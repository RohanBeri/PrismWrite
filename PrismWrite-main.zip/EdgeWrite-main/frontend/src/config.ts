export const BACKEND_URL = "https://backend.bandivivek50.workers.dev";
